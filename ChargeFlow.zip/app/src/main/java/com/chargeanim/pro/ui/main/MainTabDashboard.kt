package com.chargeanim.pro.ui.main

import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chargeanim.pro.data.AnimationMode
import com.chargeanim.pro.data.MediaType
import com.chargeanim.pro.data.PreferencesRepository
import com.chargeanim.pro.diagnostics.DiagnosticLog
import com.chargeanim.pro.history.ChargingHistoryStore
import com.chargeanim.pro.telemetry.BatteryStatusData
import com.chargeanim.pro.telemetry.ChargingMetrics
import com.chargeanim.pro.telemetry.ChargingMetricsProvider
import com.chargeanim.pro.ui.overlay.ChargingOverlayScreen
import com.chargeanim.pro.ui.theme.ThemeCatalog
import com.chargeanim.pro.ui.theme.ThemeId
import com.chargeanim.pro.ui.theme.ThemeVisual
import com.chargeanim.pro.ui.theme.FlagshipThemeVisual
import com.chargeflow.theme.ThemeId as FlagshipThemeId
import kotlinx.coroutines.launch

private enum class DashboardTab(val label: String) {
    THEMES("Skins"), VIBES("Vibes"), SETTINGS("Config"), PREVIEW("Monitor"), DIAGNOSTICS("Telemetry")
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainTabDashboard(prefs: PreferencesRepository, onLaunchOverlay: () -> Unit) {
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        runCatching {
            val intent = Intent(context, com.chargeanim.pro.service.ChargingService::class.java).apply {
                action = com.chargeanim.pro.service.ChargingService.ACTION_MONITOR
            }
            ContextCompat.startForegroundService(context, intent)
            DiagnosticLog.add(context, "Charging monitor start requested from visible app")
        }.onFailure {
            DiagnosticLog.add(context, "Charging monitor start FAILED: ${it::class.simpleName}: ${it.message}")
        }
    }
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { DashboardTab.entries.size })
    val scope = rememberCoroutineScope()
    val tab = DashboardTab.entries[pagerState.currentPage]
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)
        ) {
            Text("ChargeFlow", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.onSurface)
            Text("Charging, redesigned.", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            Text(
                "Flagship charging visuals and live telemetry.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        ScrollableTabRow(selectedTabIndex = tab.ordinal, edgePadding = 8.dp) {
            DashboardTab.entries.forEach { t ->
                Tab(
                    selected = tab == t,
                    onClick = { scope.launch { pagerState.animateScrollToPage(t.ordinal) } },
                    text = { Text(t.label) }
                )
            }
        }
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            key = { DashboardTab.entries[it].name }
        ) { page ->
            when (DashboardTab.entries[page]) {
                DashboardTab.THEMES -> ThemesTab(prefs)
                DashboardTab.VIBES -> VibesTab()
                DashboardTab.SETTINGS -> SettingsTab(prefs)
                DashboardTab.PREVIEW -> if (pagerState.currentPage == page) PreviewTab(prefs, onLaunchOverlay)
                DashboardTab.DIAGNOSTICS -> DiagnosticsTab(active = pagerState.currentPage == page)
            }
        }
    }
}

@Composable
private fun ThemesTab(prefs: PreferencesRepository) {
    val scope = rememberCoroutineScope()
    val selected by prefs.theme.collectAsStateWithLifecycle(initialValue = ThemeId.FUTURISTIC)
    LazyVerticalGrid(columns = GridCells.Fixed(2), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
        items(items = ThemeId.entries.filter { it.ordinal < 12 }, key = { it.name }) { themeId ->
            ThemeCard(themeId, themeId == selected) { scope.launch { prefs.setTheme(themeId) } }
        }
    }
}

@Composable
private fun ThemeCard(themeId: ThemeId, isSelected: Boolean, onClick: () -> Unit) {
    val style = ThemeCatalog.getValue(themeId)
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected)
                style.accentPrimary.copy(alpha = 0.12f)
            else MaterialTheme.colorScheme.surfaceContainerLow
        ),
        border = if (isSelected)
            androidx.compose.foundation.BorderStroke(1.5.dp, style.accentPrimary.copy(alpha = 0.72f))
        else null
    ) {
        Column(Modifier.padding(10.dp)) {
            Box(
                Modifier.fillMaxWidth().height(148.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                style.accentPrimary.copy(alpha = 0.16f),
                                style.accentSecondary.copy(alpha = 0.08f),
                                Color.Black
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                val flagshipId = runCatching { FlagshipThemeId.valueOf(themeId.name) }.getOrDefault(FlagshipThemeId.FUTURISTIC)
                FlagshipThemeVisual(flagshipId, Modifier.fillMaxSize(), active = false)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                themeId.label,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1
            )
            Text(
                if (isSelected) "ACTIVE EXPERIENCE" else "Tap to preview",
                style = MaterialTheme.typography.labelSmall,
                color = if (isSelected) style.accentPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 3.dp)
            )
        }
    }
}

@Composable
private fun SettingsTab(prefs: PreferencesRepository) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val enabled by prefs.enabled.collectAsStateWithLifecycle(initialValue = true)
    val animationMode by prefs.animationMode.collectAsStateWithLifecycle(initialValue = AnimationMode.TEMPORARY)
    val amoled by prefs.amoledMode.collectAsStateWithLifecycle(initialValue = true)
    val autoHide by prefs.autoHide.collectAsStateWithLifecycle(initialValue = true)
    val soundEnabled by prefs.soundEnabled.collectAsStateWithLifecycle(initialValue = false)
    val overlayGranted = remember { mutableStateOf(Settings.canDrawOverlays(context)) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                val granted = Settings.canDrawOverlays(context)
                overlayGranted.value = granted
                if (granted) {
                    runCatching {
                        val intent = Intent(context, com.chargeanim.pro.service.ChargingService::class.java).apply {
                            action = com.chargeanim.pro.service.ChargingService.ACTION_MONITOR
                        }
                        ContextCompat.startForegroundService(context, intent)
                        DiagnosticLog.add(context, "Overlay permission granted; charging monitor recheck requested")
                    }.onFailure {
                        DiagnosticLog.add(context, "Monitor recheck FAILED: " + it::class.simpleName + ": " + it.message)
                    }
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val normalMediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            scope.launch { prefs.setNormalMedia(uri.toString(), guessType(context, uri)) }
        }
    }
    val fastMediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            scope.launch { prefs.setFastMedia(uri.toString(), guessType(context, uri)) }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        SettingSwitch("Show animation when charging", enabled) { scope.launch { prefs.setEnabled(it) } }
        Spacer(Modifier.height(12.dp))
        Text("Animation mode", style = MaterialTheme.typography.titleSmall)
        Text(
            if (animationMode == AnimationMode.TEMPORARY)
                "Shows on charge and while the lock screen is active; hides after unlock."
            else
                "Stays visible continuously while charging and locked; hides after unlock.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
            Modifier.fillMaxWidth().padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = animationMode == AnimationMode.TEMPORARY,
                onClick = { scope.launch { prefs.setAnimationMode(AnimationMode.TEMPORARY) } },
                label = { Text("Temporary") }
            )
            FilterChip(
                selected = animationMode == AnimationMode.ALWAYS_ON,
                onClick = { scope.launch { prefs.setAnimationMode(AnimationMode.ALWAYS_ON) } },
                label = { Text("Always On") }
            )
        }
        Spacer(Modifier.height(12.dp))
        Text("System overlay", style = MaterialTheme.typography.titleSmall)
        Text(if (overlayGranted.value) "Enabled: ChargeFlow can appear automatically when charging." else "Required for the charging animation to appear automatically over the system.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + context.packageName))) }) {
            Text(if (overlayGranted.value) "Open overlay permission" else "Enable system overlay")
        }
        SettingSwitch("AMOLED black background", amoled) { scope.launch { prefs.setAmoledMode(it) } }
        SettingSwitch("Hide automatically when unplugged", autoHide) { scope.launch { prefs.setAutoHide(it) } }
        SettingSwitch("Play a sound when charging starts", soundEnabled) { scope.launch { prefs.setSoundEnabled(it) } }
        Spacer(Modifier.height(20.dp))
        Text("Custom media (overrides the theme visual)", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { normalMediaPicker.launch(arrayOf("*/*")) }) { Text("Normal charging…") }
            OutlinedButton(onClick = { fastMediaPicker.launch(arrayOf("*/*")) }) { Text("Fast charging…") }
        }
    }
}

@Composable
private fun DiagnosticsTab(active: Boolean) {
    val context = LocalContext.current
    var lines by remember { mutableStateOf(emptyList<String>()) }
    var sessions by remember { mutableStateOf(emptyList<com.chargeanim.pro.history.ChargingSession>()) }

    LaunchedEffect(active) {
        if (!active) return@LaunchedEffect
        while (true) {
            lines = DiagnosticLog.readAll(context)
            sessions = ChargingHistoryStore.all(context).reversed()
            kotlinx.coroutines.delay(2000L)
        }
    }

    val metricsState = remember(active) {
        if (active) ChargingMetricsProvider.acquire(context.applicationContext) else null
    }
    val metrics by (metricsState ?: kotlinx.coroutines.flow.MutableStateFlow(ChargingMetrics()))
        .collectAsStateWithLifecycle()

    DisposableEffect(active) {
        onDispose { if (active) ChargingMetricsProvider.release() }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("POWER STATE", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        MetricsPanel(metrics)
        Spacer(Modifier.height(16.dp))
        Text("RECENT CHARGING SESSIONS", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        if (sessions.isEmpty()) {
            Text("No completed charging sessions yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.heightIn(max = 220.dp)) {
                lazyItems(sessions.take(10).mapIndexed { index, session -> index to session }, key = { it.first }) { entry ->
                    val session = entry.second
                    val started = java.text.SimpleDateFormat("dd MMM, HH:mm", java.util.Locale.US).format(java.util.Date(session.startTime))
                    val ended = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US).format(java.util.Date(session.endTime))
                    val duration = ((session.endTime - session.startTime).coerceAtLeast(0L) / 60000L)
                    Text(started + " → " + ended + "   " + duration + " min   " + session.finalLevel + "%", style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(8.dp))
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Event log", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { lines = DiagnosticLog.readAll(context) }) { Text("Refresh") }
                OutlinedButton(onClick = { DiagnosticLog.clear(context); lines = emptyList() }) { Text("Clear") }
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxSize()) {
            lazyItems(lines.mapIndexed { index, line -> index to line }, key = { it.first }) { entry ->
                val line = entry.second
                Text(line, style = MaterialTheme.typography.bodySmall, modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp)).padding(8.dp))
            }
        }
    }
}

@Composable
private fun MetricsPanel(metrics: ChargingMetrics) {
    val active = metrics.hasPowerFlow
    val powerState = when {
        metrics.isFull -> "FULL"
        active -> "CHARGING • ${metrics.chargingProfile.name}"
        metrics.isCharging -> "CONNECTED • ECO / IDLE"
        else -> "NOT CHARGING"
    }
    val timeToFull = if (active) metrics.timeToFullMinutes?.let { "${it} min" } ?: "—" else "—"
    val rate = if (active && metrics.chargeRatePercentPerHour > 0.05) String.format(java.util.Locale.US, "%.1f %%/h", metrics.chargeRatePercentPerHour) else "—"
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth().background(Color(0xFF0A0E1A), RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text(powerState, color = if (active) Color(0xFF55E6FF) else Color(0xFF8793A8), style = MaterialTheme.typography.titleSmall)
        Text("BATTERY %   ${metrics.batteryPercent}%")
        Text(if (metrics.voltageVolts > 0.0) String.format(java.util.Locale.US, "VOLTAGE   %.2f V", metrics.voltageVolts) else "VOLTAGE   —")
        Text(if (active) String.format(java.util.Locale.US, "CURRENT   %.2f A", metrics.currentAmps) else "CURRENT   —")
        Text(if (active) String.format(java.util.Locale.US, "POWER     %.2f W", metrics.powerWatts) else "POWER     —")
        Text(if (metrics.temperatureCelsius > 0.0) String.format(java.util.Locale.US, "TEMPERATURE   %.1f °C", metrics.temperatureCelsius) else "TEMPERATURE   —")
        Text("CHARGE RATE   $rate")
        Text("TIME TO FULL   $timeToFull")
        Text("SESSION   ${if (active) metrics.sessionSeconds / 60 else 0} min")
    }
}
@Composable
private fun PreviewTab(prefs: PreferencesRepository, onLaunchOverlay: () -> Unit) {
    val context = LocalContext.current
    val theme by prefs.theme.collectAsStateWithLifecycle(initialValue = ThemeId.FUTURISTIC)
    val metricsState = remember { ChargingMetricsProvider.acquire(context.applicationContext) }
    val metrics by metricsState.collectAsStateWithLifecycle()
    DisposableEffect(Unit) { onDispose { ChargingMetricsProvider.release() } }

    val liveStatus = remember(metrics) {
        BatteryStatusData(
            percent = metrics.batteryPercent,
            isCharging = metrics.isCharging,
            isFastCharging = metrics.chargingProfile == com.chargeanim.pro.telemetry.ChargingProfile.TURBO,
            chargeMode = when (metrics.plugType) {
                BatteryManager.BATTERY_PLUGGED_USB -> com.chargeanim.pro.telemetry.ChargeMode.USB
                BatteryManager.BATTERY_PLUGGED_AC -> com.chargeanim.pro.telemetry.ChargeMode.AC
                BatteryManager.BATTERY_PLUGGED_WIRELESS -> com.chargeanim.pro.telemetry.ChargeMode.WIRELESS
                else -> com.chargeanim.pro.telemetry.ChargeMode.NONE
            },
            voltage = metrics.voltageVolts.toFloat().takeIf { it > 0f },
            currentMa = (metrics.currentAmps * 1000f).takeIf { it > 0.001f },
            wattage = metrics.powerWatts.toFloat().takeIf { it > 0.05f },
            temperatureC = metrics.temperatureCelsius.toFloat().takeIf { it > 0f },
            elapsedChargingMs = metrics.sessionSeconds * 1000L,
            sessionStartPercent = null
        )
    }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color.Black)
        ) {
            ChargingOverlayScreen(
                status = liveStatus,
                theme = theme,
                media = com.chargeanim.pro.data.MediaSelection(null, MediaType.NONE),
                showTelemetry = false
            )
            Text(
                "LIVE DEVICE DATA",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 14.dp)
            )
        }
        Text(
            "Monitor uses the same live metrics source as Telemetry.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
        )
        Button(onClick = onLaunchOverlay) { Text("Open full-screen") }
    }
}
@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun guessType(context: android.content.Context, uri: android.net.Uri): MediaType {
    val mime = context.contentResolver.getType(uri) ?: ""
    val path = uri.toString().lowercase()
    return when {
        mime.contains("json") || path.endsWith(".json") -> MediaType.LOTTIE
        mime.contains("gif") || path.endsWith(".gif") -> MediaType.GIF
        mime.startsWith("video") || path.endsWith(".mp4") -> MediaType.MP4
        else -> MediaType.NONE
    }
}