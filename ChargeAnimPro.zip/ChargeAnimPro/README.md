# ChargeFlow

Open-source (add a LICENSE — MIT/GPL, your call), ad-free, tracker-free Android charging animation app. Kotlin + Jetpack Compose + Material 3.

Open the folder in Android Studio (Iguana+), let Gradle sync, run on a **real device** — the emulator can't simulate a real charger plug event.

## Deliverables, file by file

| Spec item | File |
|---|---|
| `AndroidManifest.xml` | `AndroidManifest.xml` — lockscreen flags, `specialUse` foreground service, power receivers, zero `INTERNET` permission |
| `BatteryTelemetryManager.kt` | `telemetry/BatteryTelemetryManager.kt` — `StateFlow<BatteryStatusData>`: %, mode, V, mA, W, °C, fast-charge flag, elapsed + session-start % for the time-to-full estimate |
| `PowerConnectionReceiver.kt` + `ChargingService.kt` | `service/` — receiver starts a foreground service just long enough to launch the overlay, then `stopSelf()`s immediately; nothing lingers after unplug |
| `ChargeFlowThemes.kt` | `ui/theme/ChargeFlowThemes.kt` — the 12-preset catalog + dispatcher (see below for how the 12 map onto renderers) |
| `ChargingOverlayScreen.kt` | `ui/overlay/ChargingOverlayScreen.kt` — top header (icon/%/speed/wattage), center theme visual, 3-column telemetry card, temp + time-to-full badges, pulsing bottom port glow |
| `MainTabDashboard.kt` | `ui/main/MainTabDashboard.kt` — Themes (2-col grid, live mini-previews) / Settings / Preview tabs |

`ChargingOverlayActivity.kt` and `MainActivity.kt` are now intentionally thin — window flags and telemetry lifecycle only, or DataStore init only. All layout lives in the two Screen/Dashboard files above so it's previewable and testable without an Activity.

## How the 12 themes actually render

Twelve fully bespoke hand-animated Canvas renderers is a lot of surface area for one pass to respectively cover well, so this is built as **6 real rendering engines**, parameterized to produce 12 visually distinct results — same approach real theme systems use (a handful of engines, many skins), documented honestly rather than silently reusing one look 12 times:

| Engine | Themes using it | What varies |
|---|---|---|
| Ring (`EnergyRingVisual`) | Futuristic, Ice, Neon, Minimal | accent color, circle vs. triangle outline, bloom intensity |
| Particle field | Space, Fire, Nature, Anime | palette, drift direction (upward for Fire, radial burst for Anime, ambient drift for Space/Nature) |
| Lightning | Electric | dedicated — jittering radial bolts, unique to this theme |
| Liquid ripple | Water | dedicated — expanding ring pulses |
| Matrix rain | Matrix | dedicated — falling glyph columns |
| Ribbon wave | Abstract | dedicated — animated sine-wave bands |

If you want Fire and Nature to look less like palette-swapped siblings, the next step is giving `ParticleFieldRenderer` a shape parameter (embers vs. leaves) rather than always drawing circles — flagged here rather than done silently.

## Known simplifications

- **Time-to-full**: linear extrapolation from the session's starting % (`sessionStartPercent` + `elapsedChargingMs`, both tracked live in `BatteryTelemetryManager`). `BATTERY_PROPERTY_CHARGE_COUNTER` (mentioned in the spec as an alternative) reports remaining capacity in µAh, not a time — you'd still need to divide by current draw and get the same kind of estimate, so this doesn't leave meaningful accuracy on the table.
- **Voltage/current**: not guaranteed by every OEM (`BATTERY_PROPERTY_CURRENT_NOW` returns `Int.MIN_VALUE` on some Samsung/MIUI builds) — cells show "—" rather than a fake `0`.
- **Custom media picker** uses `ActivityResultContracts.GetContent()` + `takePersistableUriPermission`, exactly as specced, for Lottie JSON / GIF / MP4. Type is guessed from MIME + extension since `GetContent()` doesn't return a declared type.
- **Preview tab** renders the real `ChargingOverlayScreen` with fabricated sample telemetry (72%, 18.4 W, etc.) rather than live data, so you can browse themes without being plugged in.

## Not included on purpose

No ad SDK, no analytics/crash-reporting SDK — nothing to strip out, matching the zero-tracker requirement structurally rather than by policy.
