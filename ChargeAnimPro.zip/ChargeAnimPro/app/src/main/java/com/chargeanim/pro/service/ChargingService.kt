package com.chargeanim.pro.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.chargeanim.pro.telemetry.BatteryTelemetryManager
import com.chargeanim.pro.ui.overlay.ChargingOverlayActivity

/**
 * Deliberately minimal: this service does NOT run the telemetry loop itself
 * (the overlay Activity owns its own BatteryTelemetryManager while visible,
 * so there's no double-registered receiver). The service exists only so the
 * process isn't killed by Doze between "plug connected" and "overlay
 * Activity actually drawn", and it calls stopSelf() the instant it's done —
 * no lingering foreground notification, no battery drain of its own.
 */
class ChargingService : Service() {

    companion object {
        const val ACTION_PLUGGED_IN = "com.chargeanim.pro.action.PLUGGED_IN"
        const val ACTION_UNPLUGGED = "com.chargeanim.pro.action.UNPLUGGED"
        private const val CHANNEL_ID = "charging_service_channel"
        private const val NOTIFICATION_ID = 1001
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLUGGED_IN -> {
                startForeground(NOTIFICATION_ID, buildNotification())
                val overlay = Intent(this, ChargingOverlayActivity::class.java).apply {
                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_NO_USER_ACTION or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                    )
                }
                startActivity(overlay)
                // The overlay Activity is now responsible for its own lifecycle
                // and its own BatteryTelemetryManager instance; this service's
                // job — surviving Doze long enough to launch it — is done.
                stopSelf()
            }
            ACTION_UNPLUGGED -> {
                // The overlay Activity listens for ACTION_POWER_DISCONNECTED itself
                // and finishes on its own; nothing for the service to tear down here
                // beyond making sure it isn't left running.
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Charging animation", NotificationManager.IMPORTANCE_MIN
            ).apply { setShowBadge(false) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Charging")
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(false)
            .build()
    }
}
