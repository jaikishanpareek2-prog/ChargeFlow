package com.chargeanim.pro.media

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.provider.Settings as SystemSettings

/**
 * One-shot player: build it, call [play], it releases itself on completion.
 * No looping, no service dependency — the overlay just fires this once when
 * it appears.
 */
class AudioPlayerManager(private val context: Context) {

    fun play(customUri: String?) {
        try {
            val player = if (customUri != null) {
                MediaPlayer().apply {
                    setDataSource(context, Uri.parse(customUri))
                    prepare()
                }
            } else {
                MediaPlayer.create(context, SystemSettings.System.DEFAULT_NOTIFICATION_URI)
            }
            player?.setOnCompletionListener { it.release() }
            player?.start()
        } catch (_: Exception) {
            // Missing/unreadable file, or no default chime on this device —
            // fail silently rather than crash the overlay over a sound effect.
        }
    }
}
