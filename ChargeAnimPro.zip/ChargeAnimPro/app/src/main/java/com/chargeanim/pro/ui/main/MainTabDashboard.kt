package com.chargeanim.pro.ui.main

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.chargeanim.pro.data.MediaType
import com.chargeanim.pro.data.PreferencesRepository
import com.chargeanim.pro.telemetry.BatteryStatusData
import com.chargeanim.pro.ui.overlay.ChargingOverlayScreen
import com.chargeanim.pro.ui.theme.ThemeCatalog
import com.chargeanim.pro.ui.theme.ThemeId
import com.chargeanim.pro.ui.theme.ThemeVisual
import kotlinx.coroutines.launch

private enum class DashboardTab(val label: String) { THEMES("Themes"), SETTINGS("Settings"), PREVIEW("Preview") }

@Composable
fun MainTabDashboard(prefs: PreferencesRepository, onLaunchOverlay: () -> Unit) {
    var tab by remember { mutableStateOf(DashboardTab.THEMES) }

    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(20.dp, 20.dp, 20.dp, 8.dp)) {
            Text("ChargeFlow", style = MaterialTheme.typography.headlineMedium)
            Text(
                "No ads, no trackers, no root.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        TabRow(selectedTabIndex = tab.ordinal) {
            DashboardTab.entries.forEach { t ->
                Tab(selected = tab == t, onClick = { tab = t }, text = { Text(t.label) })
            }
        }

        when (tab) {
            DashboardTab.THEMES -> ThemesTab(prefs)
            DashboardTab.SETTINGS -> SettingsTab(prefs)
            DashboardTab.PREVIEW -> PreviewTab(prefs, onLaunchOverlay)
        }
    }
}

@Composable
private fun ThemesTab(prefs: PreferencesRepository) {
    val scope = rememberCoroutineScope()
    val selected by prefs.theme.collectAsStateWithLifecycle(initialValue = ThemeId.FUTURISTIC)

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(ThemeId.entries.toList()) { themeId ->
            ThemeCard(
                themeId = themeId,
                isSelected = themeId == selected,
                onClick = { scope.launch { prefs.setTheme(themeId) } }
            )
        }
    }
}

@Composable
private fun ThemeCard(themeId: ThemeId, isSelected: Boolean, onClick: () -> Unit) {
    val style = ThemeCatalog.getValue(themeId)
    Column(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0A0E1A))
            .then(
                if (isSelected) Modifier.background(style.accentPrimary.copy(alpha = 0.08f))
                else Modifier
            )
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clip(RoundedCornerShape(10.dp))
        ) {
            ThemeVisual(themeId = themeId, modifier = Modifier.fillMaxSize()) {
                Text("72%", color = Color(0xFFEAF4FF))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(themeId.label, color = Color(0xFFEAF4FF), style = MaterialTheme.typography.bodyMedium)
        if (isSelected) {
            Text("Selected", color = style.accentPrimary, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun SettingsTab(prefs: PreferencesRepository) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val enabled by prefs.enabled.collectAsStateWithLifecycle(initialValue = true)
    val amoled by prefs.amoledMode.collectAsStateWithLifecycle(initialValue = true)
    val autoHide by prefs.autoHide.collectAsStateWithLifecycle(initialValue = true)
    val soundEnabled by prefs.soundEnabled.collectAsStateWithLifecycle(initialValue = false)

    val normalMediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            scope.launch { prefs.setNormalMedia(uri.toString(), guessType(context, uri)) }
        }
    }
    val fastMediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            scope.launch { prefs.setFastMedia(uri.toString(), guessType(context, uri)) }
        }
    }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        SettingSwitch("Show animation when charging", enabled) { scope.launch { prefs.setEnabled(it) } }
        SettingSwitch("AMOLED black background", amoled) { scope.launch { prefs.setAmoledMode(it) } }
        SettingSwitch("Hide automatically when unplugged", autoHide) { scope.launch { prefs.setAutoHide(it) } }
        SettingSwitch("Play a sound when charging starts", soundEnabled) { scope.launch { prefs.setSoundEnabled(it) } }

        Spacer(Modifier.height(20.dp))
        Text("Custom media (overrides the theme visual)", style = MaterialTheme.typography.titleSmall)
        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { normalMediaPicker.launch("*/*") }) { Text("Normal charging\u2026") }
            OutlinedButton(onClick = { fastMediaPicker.launch("*/*") }) { Text("Fast charging\u2026") }
        }
    }
}

@Composable
private fun PreviewTab(prefs: PreferencesRepository, onLaunchOverlay: () -> Unit) {
    val theme by prefs.theme.collectAsStateWithLifecycle(initialValue = ThemeId.FUTURISTIC)
    val fakeStatus = remember {
        BatteryStatusData(
            percent = 72, isCharging = true, isFastCharging = true,
            chargeMode = com.chargeanim.pro.telemetry.ChargeMode.USB,
            voltage = 5.02f, currentMa = 3670, wattage = 18.4f,
            temperatureC = 32f, elapsedChargingMs = 11 * 60_000L, sessionStartPercent = 60
        )
    }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .padding(24.dp)
                .aspectRatio(0.5f)
                .clip(RoundedCornerShape(28.dp))
                .background(Color.Black)
        ) {
            ChargingOverlayScreen(
                status = fakeStatus,
                theme = theme,
                media = com.chargeanim.pro.data.MediaSelection(null, MediaType.NONE)
            )
        }
        Text(
            "Preview with sample data \u2014 tap Settings to launch the real overlay next time you plug in.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = onLaunchOverlay) { Text("Open full-screen now") }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun guessType(context: android.content.Context, uri: android.net.Uri): MediaType {
    val mime = context.contentResolver.getType(uri) ?: ""
    val path = uri.toString().lowercase()
    return when {
        mime.contains("json") || path.endsWith(".json") -> MediaType.LOTTIE
        mime.contains("gif") || path.endsWith(".gif") -> MediaType.GIF
        mime.startsWith("video") || path.endsWith(".mp4") -> MediaType.MP4
        else -> MediaType.NONE
    }
}
