package com.chargeanim.pro.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import kotlin.random.Random

/**
 * The rotating-rings-with-bloom centerpiece. No blur API is required (works
 * down to minSdk 26): the "glow" is entirely radial-gradient fades stacked
 * behind solid ring strokes, which reads as soft light without needing
 * Modifier.blur (API 31+ only) or a RenderEffect.
 *
 * [content] is whatever sits in the dead center — normally the bolt icon +
 * percentage text — passed in so this file stays layout-agnostic.
 */
@Composable
fun EnergyRingVisual(
    accent: Color,
    modifier: Modifier = Modifier,
    showStarfield: Boolean = true,
    bloomIntensity: Float = 1f,
    triangleShape: Boolean = false,
    content: @Composable () -> Unit
) {
    val infinite = rememberInfiniteTransition(label = "ring-rotation")
    val slowRotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(12000, easing = LinearEasing)),
        label = "slow"
    )
    val fastRotation by infinite.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "fast"
    )
    val pulse by infinite.animateFloat(
        initialValue = 0.75f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    val stars = remember {
        val rnd = Random(1)
        List(50) { Triple(rnd.nextFloat(), rnd.nextFloat(), rnd.nextFloat() * 0.5f + 0.1f) }
    }

    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = size.minDimension / 2f

            if (showStarfield) {
                stars.forEach { (fx, fy, alpha) ->
                    drawCircle(
                        color = Color.White.copy(alpha = alpha * 0.5f),
                        radius = 1.2f,
                        center = Offset(fx * size.width, fy * size.height)
                    )
                }
            }

            // Bloom: three oversized radial gradients fading to transparent,
            // brightest near the center, standing in for a blur-based glow.
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.35f * pulse * bloomIntensity), Color.Transparent),
                    center = center,
                    radius = maxRadius * 1.1f
                ),
                radius = maxRadius * 1.1f,
                center = center
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(accent.copy(alpha = 0.55f * pulse * bloomIntensity), Color.Transparent),
                    center = center,
                    radius = maxRadius * 0.55f
                ),
                radius = maxRadius * 0.55f,
                center = center
            )

            if (triangleShape) {
                // Neon-triangle variant: same rotation/pulse rig, a triangle path instead of arcs.
                withTransform({ rotate(slowRotation, center) }) {
                    val r = maxRadius * 0.92f
                    val path = androidx.compose.ui.graphics.Path().apply {
                        for (i in 0..3) {
                            val angle = Math.toRadians((-90 + i * 120).toDouble())
                            val x = center.x + r * kotlin.math.cos(angle).toFloat()
                            val y = center.y + r * kotlin.math.sin(angle).toFloat()
                            if (i == 0) moveTo(x, y) else lineTo(x, y)
                        }
                    }
                    drawPath(path, color = accent.copy(alpha = 0.8f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f))
                }
            } else {
                // Outer ring: broken into arcs so the rotation reads clearly.
                withTransform({ rotate(slowRotation, center) }) {
                    for (i in 0 until 8) {
                        drawArc(
                            color = accent.copy(alpha = 0.7f),
                            startAngle = i * 45f,
                            sweepAngle = 28f,
                            useCenter = false,
                            topLeft = Offset(center.x - maxRadius * 0.92f, center.y - maxRadius * 0.92f),
                            size = androidx.compose.ui.geometry.Size(maxRadius * 1.84f, maxRadius * 1.84f),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
                        )
                    }
                }
            }

            // Inner ring, counter-rotating, solid stroke.
            withTransform({ rotate(fastRotation, center) }) {
                drawCircle(
                    color = accent.copy(alpha = 0.9f),
                    radius = maxRadius * 0.62f,
                    center = center,
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
                )
                // A single bright notch on the inner ring so the counter-rotation is visible.
                drawArc(
                    color = Color.White.copy(alpha = 0.9f),
                    startAngle = 0f,
                    sweepAngle = 14f,
                    useCenter = false,
                    topLeft = Offset(center.x - maxRadius * 0.62f, center.y - maxRadius * 0.62f),
                    size = androidx.compose.ui.geometry.Size(maxRadius * 1.24f, maxRadius * 1.24f),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
                )
            }

            // Static faint reference ring so the layout doesn't feel empty
            // between the two moving rings.
            drawCircle(
                color = accent.copy(alpha = 0.25f),
                radius = maxRadius * 0.78f,
                center = center,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1f)
            )
        }
        content()
    }
}
