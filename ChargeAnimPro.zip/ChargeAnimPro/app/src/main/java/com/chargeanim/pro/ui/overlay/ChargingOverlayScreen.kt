package com.chargeanim.pro.ui.overlay

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chargeanim.pro.data.MediaSelection
import com.chargeanim.pro.media.MediaRenderer
import com.chargeanim.pro.telemetry.BatteryStatusData
import com.chargeanim.pro.telemetry.ChargeMode
import com.chargeanim.pro.ui.theme.ThemeCatalog
import com.chargeanim.pro.ui.theme.ThemeId
import com.chargeanim.pro.ui.theme.ThemeVisual

/**
 * Pure layout — no Activity/window concerns here, so it's previewable and
 * reusable from the in-app "Preview" tab without dragging WindowManager
 * flags along with it.
 */
@Composable
fun ChargingOverlayScreen(
    status: BatteryStatusData,
    theme: ThemeId,
    media: MediaSelection,
    showTelemetry: Boolean = true
) {
    val accent = ThemeCatalog.getValue(theme).accentPrimary

    Box(Modifier.fillMaxSize().background(Color.Black)) {

        // --- Top center header: icon, live %, speed, wattage ---
        Row(
            Modifier.align(Alignment.TopCenter).padding(top = 28.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(Icons.Filled.Bolt, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
            Text("${status.percent}%", fontSize = 15.sp, color = Color(0xFFEAF4FF))
            Text("\u2022", color = Color(0xFF44506A), fontSize = 13.sp)
            Text(speedLabel(status), fontSize = 13.sp, color = accent)
            if (status.wattage != null) {
                Text("\u2022", color = Color(0xFF44506A), fontSize = 13.sp)
                Text("%.1f W".format(status.wattage), fontSize = 13.sp, color = Color(0xFF8B9AB0))
            }
        }

        // --- Center: theme-driven ring/particle/etc. visual wrapping the big status text ---
        Box(Modifier.align(Alignment.Center).size(260.dp), contentAlignment = Alignment.Center) {
            if (media.uri != null) {
                MediaRenderer(selection = media, modifier = Modifier.fillMaxSize()) {}
            } else {
                ThemeVisual(themeId = theme, modifier = Modifier.fillMaxSize()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${status.percent}%", fontSize = 44.sp, color = Color(0xFFEAF4FF))
                        Text(speedLabel(status), fontSize = 14.sp, color = accent)
                    }
                }
            }
        }

        // --- Bottom stack: telemetry card, status banner + time badge, port glow ---
        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp).fillMaxWidth(0.86f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (showTelemetry) {
                TelemetryCard(status, accent)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatusBanner(status, accent)
                    TimeBadge(status, accent)
                }
                Spacer(Modifier.height(28.dp))
            }
            PortGlow(accent)
        }
    }
}

@Composable
private fun TelemetryCard(status: BatteryStatusData, accent: Color) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF0A0E1A), androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        MetricCell("Voltage", status.voltage?.let { "%.2f V".format(it) })
        MetricCell("Current", status.currentMa?.let { "%.2f A".format(it / 1000f) })
        MetricCell("Power", status.wattage?.let { "%.1f W".format(it) })
    }
}

@Composable
private fun MetricCell(label: String, value: String?) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value ?: "\u2014", fontSize = 15.sp, color = Color(0xFFEAF4FF))
        Text(label, fontSize = 10.sp, color = Color(0xFF6B7788))
    }
}

@Composable
private fun StatusBanner(status: BatteryStatusData, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Icon(Icons.Filled.Thermostat, contentDescription = null, tint = Color(0xFF6B7788), modifier = Modifier.size(14.dp))
        Text(
            status.temperatureC?.let { "%.0f\u00B0C".format(it) } ?: "\u2014",
            fontSize = 12.sp, color = Color(0xFF9AA8BA)
        )
    }
}

@Composable
private fun TimeBadge(status: BatteryStatusData, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        Icon(Icons.Filled.Schedule, contentDescription = null, tint = Color(0xFF6B7788), modifier = Modifier.size(14.dp))
        Text(timeToFullLabel(status), fontSize = 12.sp, color = Color(0xFF9AA8BA))
    }
}

/** Small pulsing glow anchored at the very bottom, standing in for the charging port / cable. */
@Composable
private fun PortGlow(accent: Color) {
    val infinite = rememberInfiniteTransition(label = "port")
    val pulse by infinite.animateFloat(
        0.5f, 1f, infiniteRepeatable(tween(1000, easing = LinearEasing), RepeatMode.Reverse), label = "pulse"
    )
    Canvas(Modifier.fillMaxWidth().height(36.dp)) {
        val center = Offset(size.width / 2f, size.height)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(accent.copy(alpha = 0.5f * pulse), Color.Transparent),
                center = center, radius = size.width * 0.18f
            ),
            radius = size.width * 0.18f, center = center
        )
        drawCircle(accent.copy(alpha = 0.9f), radius = 4f, center = Offset(size.width / 2f, size.height - 6f))
    }
}

private fun speedLabel(status: BatteryStatusData): String = when {
    !status.isCharging -> "Not charging"
    status.isFastCharging -> "Fast Charging"
    else -> "Charging"
}

/** Same session-rate estimate the telemetry manager already tracks (sessionStartPercent + elapsedChargingMs). */
private fun timeToFullLabel(status: BatteryStatusData): String {
    if (!status.isCharging) return "\u2014"
    if (status.percent >= 100) return "Full"
    val start = status.sessionStartPercent ?: return "Estimating\u2026"
    val elapsedMin = status.elapsedChargingMs / 60000f
    val gained = status.percent - start
    if (elapsedMin < 1f || gained <= 0) return "Estimating\u2026"
    val ratePerMin = gained / elapsedMin
    val minutesLeft = ((100 - status.percent) / ratePerMin).toInt()
    return if (minutesLeft in 0..600) "$minutesLeft min to full" else "Estimating\u2026"
}
