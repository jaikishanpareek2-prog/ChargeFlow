package com.chargeanim.pro.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

enum class ThemeId(val label: String) {
    FUTURISTIC("Futuristic"), SPACE("Space"), ELECTRIC("Electric"), FIRE("Fire"),
    WATER("Water"), ICE("Ice"), NEON("Neon"), MATRIX("Matrix"),
    NATURE("Nature"), MINIMAL("Minimal"), ANIME("Anime"), ABSTRACT("Abstract")
}

enum class RendererKind { RING, RING_MINIMAL, RING_TRIANGLE, PARTICLE_FIELD, LIGHTNING, LIQUID_RIPPLE, MATRIX_RAIN, RIBBON_WAVE }

data class ThemeStyle(
    val accentPrimary: Color,
    val accentSecondary: Color,
    val renderer: RendererKind,
    /** Only used by PARTICLE_FIELD: which way particles drift. */
    val particleDrift: ParticleDrift = ParticleDrift.RADIAL
)

enum class ParticleDrift { UP, RADIAL, DRIFT }

/**
 * Every preset, honestly: FUTURISTIC/ICE/NEON/MINIMAL share the ring engine
 * (shape/bloom/color parameters only — see EnergyRingVisual). SPACE/FIRE/
 * NATURE/ANIME share the particle-field engine (palette + drift direction
 * only). ELECTRIC, WATER, MATRIX and ABSTRACT each get their own dedicated
 * renderer below because their motion genuinely doesn't reduce to "ring" or
 * "particles". Twelve fully bespoke hand-animated renderers was more surface
 * area than a single pass could responsibly cover — this gets you 6 real
 * rendering engines and 12 visually distinct results from them.
 */
val ThemeCatalog: Map<ThemeId, ThemeStyle> = mapOf(
    ThemeId.FUTURISTIC to ThemeStyle(Color(0xFF4FC3FF), Color(0xFFEAF4FF), RendererKind.RING),
    ThemeId.SPACE to ThemeStyle(Color(0xFF8A6FFF), Color(0xFF4FC3FF), RendererKind.PARTICLE_FIELD, ParticleDrift.DRIFT),
    ThemeId.ELECTRIC to ThemeStyle(Color(0xFFB84FFF), Color(0xFFE8D4FF), RendererKind.LIGHTNING),
    ThemeId.FIRE to ThemeStyle(Color(0xFFFF6A2E), Color(0xFFFFC24F), RendererKind.PARTICLE_FIELD, ParticleDrift.UP),
    ThemeId.WATER to ThemeStyle(Color(0xFF2ED9E8), Color(0xFF8FF0FF), RendererKind.LIQUID_RIPPLE),
    ThemeId.ICE to ThemeStyle(Color(0xFFBFE8FF), Color(0xFFEAF7FF), RendererKind.RING_TRIANGLE),
    ThemeId.NEON to ThemeStyle(Color(0xFFFF2EC4), Color(0xFF2EF0FF), RendererKind.RING_TRIANGLE),
    ThemeId.MATRIX to ThemeStyle(Color(0xFF2EFF6A), Color(0xFF0AFF2E), RendererKind.MATRIX_RAIN),
    ThemeId.NATURE to ThemeStyle(Color(0xFF6FE070), Color(0xFFC9FF6F), RendererKind.PARTICLE_FIELD, ParticleDrift.DRIFT),
    ThemeId.MINIMAL to ThemeStyle(Color(0xFFE8E8EC), Color(0xFF8A8A90), RendererKind.RING_MINIMAL),
    ThemeId.ANIME to ThemeStyle(Color(0xFFFF6FD8), Color(0xFF6FC4FF), RendererKind.PARTICLE_FIELD, ParticleDrift.RADIAL),
    ThemeId.ABSTRACT to ThemeStyle(Color(0xFFFF6FD8), Color(0xFF6FE0FF), RendererKind.RIBBON_WAVE)
)

/** Dispatches to whichever renderer this theme is mapped to. */
@Composable
fun ThemeVisual(themeId: ThemeId, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val style = ThemeCatalog.getValue(themeId)
    when (style.renderer) {
        RendererKind.RING -> EnergyRingVisual(style.accentPrimary, modifier, content = content)
        RendererKind.RING_TRIANGLE -> EnergyRingVisual(style.accentPrimary, modifier, triangleShape = true, content = content)
        RendererKind.RING_MINIMAL -> EnergyRingVisual(
            style.accentPrimary, modifier, showStarfield = false, bloomIntensity = 0.2f, content = content
        )
        RendererKind.PARTICLE_FIELD -> ParticleFieldRenderer(style.accentPrimary, style.accentSecondary, style.particleDrift, modifier, content)
        RendererKind.LIGHTNING -> LightningRenderer(style.accentPrimary, style.accentSecondary, modifier, content)
        RendererKind.LIQUID_RIPPLE -> LiquidRippleRenderer(style.accentPrimary, modifier, content)
        RendererKind.MATRIX_RAIN -> MatrixRainRenderer(style.accentPrimary, modifier, content)
        RendererKind.RIBBON_WAVE -> RibbonWaveRenderer(style.accentPrimary, style.accentSecondary, modifier, content)
    }
}

@Composable
private fun ParticleFieldRenderer(
    primary: Color, secondary: Color, drift: ParticleDrift, modifier: Modifier, content: @Composable () -> Unit
) {
    val infinite = rememberInfiniteTransition(label = "particles")
    val t by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "t")
    val particles = remember {
        val rnd = Random(2)
        List(70) { Triple(rnd.nextFloat(), rnd.nextFloat(), rnd.nextFloat()) } // x, y, size/speed seed
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            particles.forEachIndexed { i, (fx, fy, seed) ->
                val phase = (t + seed) % 1f
                val point = when (drift) {
                    ParticleDrift.UP -> Offset(fx * size.width, size.height * (1f - phase))
                    ParticleDrift.DRIFT -> Offset(
                        cx + (fx - 0.5f) * size.width * 0.9f + 12f * sin(phase * 2 * PI.toFloat() + i),
                        cy + (fy - 0.5f) * size.height * 0.9f + 12f * cos(phase * 2 * PI.toFloat() + i)
                    )
                    ParticleDrift.RADIAL -> {
                        val angle = i * 0.45f
                        val r = phase * size.minDimension * 0.5f
                        Offset(cx + r * cos(angle), cy + r * sin(angle))
                    }
                }
                val color = if (i % 2 == 0) primary else secondary
                val alpha = if (drift == ParticleDrift.RADIAL) (1f - phase) else (0.4f + 0.4f * sin(phase * PI.toFloat()))
                drawCircle(color.copy(alpha = alpha.coerceIn(0f, 1f) * 0.8f), radius = 2.5f + seed * 3f, center = point)
            }
            drawCircle(
                brush = Brush.radialGradient(listOf(primary.copy(alpha = 0.3f), Color.Transparent), center = Offset(cx, cy), radius = size.minDimension * 0.5f),
                radius = size.minDimension * 0.5f, center = Offset(cx, cy)
            )
        }
        content()
    }
}

@Composable
private fun LightningRenderer(primary: Color, secondary: Color, modifier: Modifier, content: @Composable () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "lightning")
    val jitter by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(260, easing = LinearEasing), RepeatMode.Reverse), label = "jitter")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val r = size.minDimension / 2f
            drawCircle(
                brush = Brush.radialGradient(listOf(secondary.copy(alpha = 0.25f), Color.Transparent), center = center, radius = r),
                radius = r, center = center
            )
            val rnd = Random((jitter * 1000).toInt())
            for (i in 0 until 6) {
                val angle = i * (2 * PI / 6) + jitter * 0.3
                val path = Path().apply {
                    var x = center.x; var y = center.y
                    moveTo(x, y)
                    val steps = 4
                    for (s in 1..steps) {
                        val t = s / steps.toFloat()
                        val jag = (rnd.nextFloat() - 0.5f) * 14f
                        x = center.x + (r * 0.85f * t * cos(angle)).toFloat() + jag
                        y = center.y + (r * 0.85f * t * sin(angle)).toFloat() + jag
                        lineTo(x, y)
                    }
                }
                drawPath(path, color = primary.copy(alpha = 0.85f), style = Stroke(width = 2.5f))
            }
        }
        content()
    }
}

@Composable
private fun LiquidRippleRenderer(accent: Color, modifier: Modifier, content: @Composable () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "ripple")
    val t by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "t")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxR = size.minDimension / 2.1f
            for (i in 0..2) {
                val phase = (t + i / 3f) % 1f
                drawCircle(
                    color = accent.copy(alpha = ((1f - phase) * 0.8f).coerceIn(0f, 1f)),
                    radius = phase * maxR,
                    center = center,
                    style = Stroke(width = 3f)
                )
            }
            drawCircle(
                brush = Brush.radialGradient(listOf(accent.copy(alpha = 0.4f), Color.Transparent), center = center, radius = maxR * 0.5f),
                radius = maxR * 0.5f, center = center
            )
        }
        content()
    }
}

@Composable
private fun MatrixRainRenderer(accent: Color, modifier: Modifier, content: @Composable () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "matrix")
    val t by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing)), label = "t")
    val columns = remember {
        val rnd = Random(3)
        List(14) { Pair(rnd.nextFloat(), rnd.nextFloat() * 0.6f + 0.4f) } // x fraction, speed seed
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            columns.forEachIndexed { i, (fx, speed) ->
                val phase = (t * speed + i * 0.07f) % 1f
                val x = fx * size.width
                val headY = phase * size.height * 1.4f - size.height * 0.2f
                for (g in 0 until 8) {
                    val y = headY - g * 14f
                    if (y < 0 || y > size.height) continue
                    drawCircle(accent.copy(alpha = (1f - g / 8f) * 0.8f), radius = 2f, center = Offset(x, y))
                }
            }
        }
        content()
    }
}

@Composable
private fun RibbonWaveRenderer(primary: Color, secondary: Color, modifier: Modifier, content: @Composable () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "ribbon")
    val phase by infinite.animateFloat(0f, 2 * PI.toFloat(), infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "phase")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            for (band in 0 until 3) {
                val path = Path()
                val color = if (band % 2 == 0) primary else secondary
                val amplitude = size.height * 0.06f
                val yBase = size.height * (0.3f + band * 0.2f)
                var started = false
                var x = 0f
                while (x <= size.width) {
                    val y = yBase + amplitude * sin(x / size.width * 4 * PI.toFloat() + phase + band)
                    if (!started) { path.moveTo(x, y); started = true } else path.lineTo(x, y)
                    x += 8f
                }
                drawPath(path, color = color.copy(alpha = 0.7f), style = Stroke(width = 3f))
            }
        }
        content()
    }
}
