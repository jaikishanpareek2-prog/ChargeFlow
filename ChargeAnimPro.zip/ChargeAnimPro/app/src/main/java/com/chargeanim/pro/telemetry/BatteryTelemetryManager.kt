package com.chargeanim.pro.telemetry

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs

enum class ChargeMode { AC, USB, WIRELESS, DISCHARGING }

data class BatteryStatusData(
    val percent: Int = 0,
    val chargeMode: ChargeMode = ChargeMode.DISCHARGING,
    val isCharging: Boolean = false,
    val voltage: Float? = null,       // volts
    val currentMa: Int? = null,       // milliamps
    val wattage: Float? = null,       // watts, V * I
    val temperatureC: Float? = null,  // celsius
    val isFastCharging: Boolean = false,
    val elapsedChargingMs: Long = 0L,
    val sessionStartPercent: Int? = null
)

/**
 * Wraps the sticky ACTION_BATTERY_CHANGED broadcast in a StateFlow so any
 * Composable can `collectAsState()` it directly. One receiver instance per
 * process lifetime is enough — call [start] once (e.g. from the Service or
 * the overlay Activity's onCreate) and [stop] when nothing needs live data
 * anymore, so we're not holding a registered receiver for no reason.
 */
class BatteryTelemetryManager(private val appContext: Context) {

    private val _state = MutableStateFlow(BatteryStatusData())
    val state: StateFlow<BatteryStatusData> = _state.asStateFlow()

    private var chargingStartedAtElapsed: Long? = null
    private var chargingStartPercent: Int? = null
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            _state.value = parse(intent)
        }
    }

    fun start() {
        if (registered) return
        val sticky = appContext.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        registered = true
        if (sticky != null) _state.value = parse(sticky)
    }

    fun stop() {
        if (!registered) return
        try {
            appContext.unregisterReceiver(receiver)
        } catch (_: IllegalArgumentException) {
            // Already unregistered elsewhere — fine, this is a defensive teardown.
        }
        registered = false
        chargingStartedAtElapsed = null
    }

    private fun parse(intent: Intent): BatteryStatusData {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val percent = if (level >= 0 && scale > 0) level * 100 / scale else 0

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)
        val mode = when {
            !charging -> ChargeMode.DISCHARGING
            plugged == BatteryManager.BATTERY_PLUGGED_AC -> ChargeMode.AC
            plugged == BatteryManager.BATTERY_PLUGGED_USB -> ChargeMode.USB
            plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS -> ChargeMode.WIRELESS
            else -> ChargeMode.DISCHARGING
        }

        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val voltage = if (voltageMv > 0) voltageMv / 1000f else null

        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val temperature = if (tempTenths > 0) tempTenths / 10f else null

        var currentMa: Int? = null
        try {
            val bm = appContext.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val micro = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
            if (micro != Int.MIN_VALUE && micro != 0) currentMa = abs(micro) / 1000
        } catch (_: Exception) {
            // Not exposed on this OEM build — leave null, UI hides the row.
        }

        val wattage = if (voltage != null && currentMa != null) (voltage * currentMa) / 1000f else null
        val fast = charging && ((wattage ?: 0f) >= 15f || (currentMa ?: 0) > 2500)

        if (charging && chargingStartedAtElapsed == null) {
            chargingStartedAtElapsed = SystemClock.elapsedRealtime()
            chargingStartPercent = percent
        } else if (!charging) {
            chargingStartedAtElapsed = null
            chargingStartPercent = null
        }
        val elapsed = chargingStartedAtElapsed?.let { SystemClock.elapsedRealtime() - it } ?: 0L

        return BatteryStatusData(
            percent = percent,
            chargeMode = mode,
            isCharging = charging,
            voltage = voltage,
            currentMa = currentMa,
            wattage = wattage,
            temperatureC = temperature,
            isFastCharging = fast,
            elapsedChargingMs = elapsed,
            sessionStartPercent = chargingStartPercent
        )
    }
}
