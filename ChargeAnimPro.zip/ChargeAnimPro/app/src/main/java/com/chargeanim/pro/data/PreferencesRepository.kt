package com.chargeanim.pro.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.chargeanim.pro.ui.theme.ThemeId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "chargeanim_prefs")

enum class MediaType { LOTTIE, GIF, MP4, NONE }

data class MediaSelection(val uri: String?, val type: MediaType)

/**
 * Everything the user configures lives here as a Flow, so the Compose UI in
 * MainActivity and the overlay both observe the same source of truth without
 * passing state through Intent extras.
 */
class PreferencesRepository(private val context: Context) {

    private object Keys {
        val ENABLED = booleanPreferencesKey("enabled")
        val AMOLED = booleanPreferencesKey("amoled_mode")
        val AUTO_HIDE = booleanPreferencesKey("auto_hide")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val CUSTOM_SOUND_URI = stringPreferencesKey("custom_sound_uri")
        val THEME = stringPreferencesKey("overlay_theme")
        val NORMAL_MEDIA_URI = stringPreferencesKey("normal_media_uri")
        val NORMAL_MEDIA_TYPE = stringPreferencesKey("normal_media_type")
        val FAST_MEDIA_URI = stringPreferencesKey("fast_media_uri")
        val FAST_MEDIA_TYPE = stringPreferencesKey("fast_media_type")
    }

    val enabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.ENABLED] ?: true }
    val amoledMode: Flow<Boolean> = context.dataStore.data.map { it[Keys.AMOLED] ?: true }
    val autoHide: Flow<Boolean> = context.dataStore.data.map { it[Keys.AUTO_HIDE] ?: true }
    val soundEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.SOUND_ENABLED] ?: false }
    val customSoundUri: Flow<String?> = context.dataStore.data.map { it[Keys.CUSTOM_SOUND_URI] }

    val theme: Flow<ThemeId> = context.dataStore.data.map {
        runCatching { ThemeId.valueOf(it[Keys.THEME] ?: ThemeId.FUTURISTIC.name) }
            .getOrDefault(ThemeId.FUTURISTIC)
    }

    val normalMedia: Flow<MediaSelection> = context.dataStore.data.map {
        MediaSelection(
            uri = it[Keys.NORMAL_MEDIA_URI],
            type = runCatching { MediaType.valueOf(it[Keys.NORMAL_MEDIA_TYPE] ?: MediaType.NONE.name) }.getOrDefault(MediaType.NONE)
        )
    }
    val fastMedia: Flow<MediaSelection> = context.dataStore.data.map {
        MediaSelection(
            uri = it[Keys.FAST_MEDIA_URI],
            type = runCatching { MediaType.valueOf(it[Keys.FAST_MEDIA_TYPE] ?: MediaType.NONE.name) }.getOrDefault(MediaType.NONE)
        )
    }

    suspend fun setEnabled(v: Boolean) = context.dataStore.edit { it[Keys.ENABLED] = v }
    suspend fun setAmoledMode(v: Boolean) = context.dataStore.edit { it[Keys.AMOLED] = v }
    suspend fun setAutoHide(v: Boolean) = context.dataStore.edit { it[Keys.AUTO_HIDE] = v }
    suspend fun setSoundEnabled(v: Boolean) = context.dataStore.edit { it[Keys.SOUND_ENABLED] = v }
    suspend fun setCustomSoundUri(uri: String?) = context.dataStore.edit {
        if (uri == null) it.remove(Keys.CUSTOM_SOUND_URI) else it[Keys.CUSTOM_SOUND_URI] = uri
    }
    suspend fun setTheme(theme: ThemeId) = context.dataStore.edit { it[Keys.THEME] = theme.name }

    suspend fun setNormalMedia(uri: String, type: MediaType) = context.dataStore.edit {
        it[Keys.NORMAL_MEDIA_URI] = uri
        it[Keys.NORMAL_MEDIA_TYPE] = type.name
    }
    suspend fun setFastMedia(uri: String, type: MediaType) = context.dataStore.edit {
        it[Keys.FAST_MEDIA_URI] = uri
        it[Keys.FAST_MEDIA_TYPE] = type.name
    }
}
