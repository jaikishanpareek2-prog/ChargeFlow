package com.chargeanim.pro.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.chargeanim.pro.data.PreferencesRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first

/**
 * Fires even when the app process is dead, because it's declared in the
 * manifest against a protected system broadcast. Its only job is to decide
 * whether ChargingService should start — all the actual telemetry/overlay
 * work lives in the service so it survives past this receiver's short
 * execution window.
 */
class PowerConnectionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_POWER_CONNECTED -> {
                val pending = goAsync()
                CoroutineScope(Dispatchers.Default).launch {
                    try {
                        val enabled = PreferencesRepository(context.applicationContext).enabled.first()
                        if (enabled) {
                            val serviceIntent = Intent(context, ChargingService::class.java)
                                .setAction(ChargingService.ACTION_PLUGGED_IN)
                            ContextCompat.startForegroundService(context, serviceIntent)
                        }
                    } finally {
                        pending.finish()
                    }
                }
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                val serviceIntent = Intent(context, ChargingService::class.java)
                    .setAction(ChargingService.ACTION_UNPLUGGED)
                context.startService(serviceIntent)
            }
            Intent.ACTION_BOOT_COMPLETED -> {
                // No persistent work to restart — the manifest receiver itself
                // is the only thing that needs to survive a reboot, and it does.
            }
        }
    }
}
